const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') || '*' }));
app.use(express.json({ limit: '16mb' })); // Large leases need room

const MODEL = 'claude-sonnet-4-6';
const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';

// ─────────────────────────────────────────────
// CLAUDE HELPER
// ─────────────────────────────────────────────

async function callClaude(system, user, maxTokens = 2000) {
  const res = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: user }]
    })
  });
  if (!res.ok) throw new Error(`Claude API ${res.status}: ${await res.text()}`);
  return (await res.json()).content[0].text;
}

function parseJSON(raw) {
  try { return JSON.parse(raw.replace(/```(?:json)?|```/g, '').trim()); }
  catch { return null; }
}

// ─────────────────────────────────────────────
// SYSTEM PROMPTS
// ─────────────────────────────────────────────

const ABSTRACTION_SYSTEM = `You are LeaseLens AI, an expert commercial real estate lease abstraction engine. You extract and organize all critical information from commercial lease documents with high accuracy.

EXTRACT ALL OF THE FOLLOWING (return null for any field not found in the document):

PARTIES & PROPERTY:
- Landlord name and address
- Tenant name, entity type, and address
- Property address, suite/unit, building name
- Rentable square footage (RSF)
- Usable square footage (USF)
- Property type (office, retail, industrial, flex, medical, mixed-use)

FINANCIAL TERMS:
- Base rent ($/SF/year and $/month)
- Rent commencement date
- Rent escalations (annual percentage, CPI-based, or fixed step-ups with schedule)
- Security deposit amount and form (cash, LOC)
- Free rent period (months and estimated value)
- Tenant improvement (TI) allowance ($/SF and total)
- Operating expense (OpEx) structure: gross/modified gross/NNN/full service
- CAM charges: included or excluded items, cap, base year
- Base year for operating expenses (if gross or modified gross)
- Property tax responsibility
- Insurance responsibility

LEASE TERM:
- Lease commencement date
- Lease expiration date
- Lease term (months)
- Possession date

OPTIONS & RIGHTS:
- Renewal options (number, term, notice period, rent structure)
- Termination option (date, penalty, notice period)
- Expansion option (space, notice, terms)
- Right of First Refusal (ROFR) on adjacent space
- Right of First Offer (ROFO)
- Purchase option

KEY CLAUSES:
- Personal guarantee (required? who? duration? burn-off?)
- Assignment and subletting rights
- Permitted use clause (exact language if possible)
- Exclusive use / radius restriction
- Co-tenancy clause (trigger, remedy, termination right)
- Force majeure provisions
- Holdover rent (percentage over base)
- Parking: spaces, cost, ratio
- Signage rights
- Audit rights for CAM
- HVAC responsibility and hours
- After-hours HVAC cost
- ADA compliance responsibility
- Environmental representations
- Default cure periods (monetary, non-monetary)
- Subordination, Non-Disturbance and Attornment (SNDA) clause present?
- Estoppel certificate obligation

RESPOND ONLY WITH VALID JSON:
{
  "abstractedAt": "<ISO timestamp>",
  "confidence": "<high|medium|low — based on document clarity>",
  "propertyType": "<string>",
  "parties": {
    "landlord": "<string>",
    "tenant": "<string>",
    "propertyAddress": "<string>",
    "suite": "<string>"
  },
  "term": {
    "commencement": "<YYYY-MM-DD or string>",
    "expiration": "<YYYY-MM-DD or string>",
    "termMonths": <number or null>,
    "possession": "<string or null>",
    "rentCommencement": "<string or null>"
  },
  "financial": {
    "rsf": <number or null>,
    "usf": <number or null>,
    "baseRentPerSF": <number or null>,
    "baseRentMonthly": <number or null>,
    "baseRentAnnual": <number or null>,
    "escalations": "<string description>",
    "escalationSchedule": [{ "date": "<string>", "rate": "<string>", "newRent": "<string>" }],
    "opexStructure": "<NNN|Gross|Modified Gross|Full Service|Other>",
    "camDetails": "<string>",
    "securityDeposit": "<string or null>",
    "tiAllowancePSF": <number or null>,
    "tiAllowanceTotal": <number or null>,
    "freeRentMonths": <number or null>,
    "freeRentValue": <number or null>
  },
  "options": {
    "renewal": [{ "term": "<string>", "notice": "<string>", "rent": "<string>", "notes": "<string>" }],
    "termination": { "date": "<string or null>", "penalty": "<string or null>", "notice": "<string or null>" },
    "expansion": "<string or null>",
    "rofr": "<string or null>",
    "rofo": "<string or null>",
    "purchase": "<string or null>"
  },
  "keyClauses": {
    "permittedUse": "<string>",
    "exclusiveUse": "<string or null>",
    "coTenancy": "<string or null>",
    "personalGuarantee": "<string or null>",
    "assignmentSubletting": "<string>",
    "holdoverRent": "<string or null>",
    "parking": "<string or null>",
    "signage": "<string or null>",
    "hvac": "<string>",
    "afterHoursHvac": "<string or null>",
    "adaResponsibility": "<string>",
    "defaultCurePeriods": "<string>",
    "sndaPresent": <boolean or null>,
    "estoppelObligation": "<string or null>",
    "camAuditRights": "<string or null>",
    "forceMAjeure": "<string or null>"
  },
  "riskFlags": [
    {
      "id": "<string>",
      "clause": "<clause name>",
      "severity": "<critical|high|medium|low>",
      "finding": "<specific concern>",
      "recommendation": "<what to do>",
      "tenantFavorable": <boolean>
    }
  ],
  "negotiationLeverage": {
    "tenantStrengths": ["<string>"],
    "tenantWeaknesses": ["<string>"],
    "keyNegotiationPoints": ["<string>"]
  },
  "executiveSummary": "<3-4 sentence professional summary of the deal>",
  "totalLeaseCost": <number or null>,
  "effectiveRentPSF": <number or null>
}`;

const CLAUSE_COMPARE_SYSTEM = `You are LeaseLens AI, an expert commercial lease analyst. Compare two lease clauses or terms and provide a professional analysis.

Analyze:
1. How they differ substantively
2. Which is more tenant-favorable and why
3. Which is more landlord-favorable and why
4. Market standard for this clause type
5. Recommended negotiation position

RESPOND ONLY WITH VALID JSON:
{
  "clauseType": "<string>",
  "comparison": {
    "leaseA": "<string — description of Lease A provision>",
    "leaseB": "<string — description of Lease B provision>",
    "keyDifferences": ["<string>"],
    "tenantFavorable": "<A|B|tied>",
    "landlordFavorable": "<A|B|tied>",
    "tenantFavorableReason": "<string>",
    "landlordFavorableReason": "<string>"
  },
  "marketStandard": "<string — what is typical in market>",
  "recommendation": "<string — specific negotiation advice>",
  "riskLevel": "<high|medium|low>"
}`;

const LOI_SYSTEM = `You are LeaseLens AI, an expert commercial real estate attorney and broker. Draft a professional Letter of Intent (LOI) for a commercial lease transaction based on the provided deal terms.

DRAFTING STANDARDS:
• Professional, clear, unambiguous language
• Include all standard LOI sections for commercial leases
• Mark negotiable vs. non-negotiable items clearly
• Include standard non-binding disclaimer language
• Fair Housing and equal opportunity language where applicable
• Add [BRACKETS] for items requiring customization
• Flag any terms that may require legal review

REQUIRED SECTIONS:
1. Parties and property identification
2. Lease term and possession date
3. Rent structure and escalations
4. Operating expenses and CAM
5. Security deposit
6. Tenant improvement allowance
7. Renewal/extension options
8. Permitted use
9. Parking
10. Signage
11. Contingencies
12. Non-binding disclaimer
13. Expiration of LOI
14. Signature blocks

End with: "⚠️ This LOI is a template for discussion purposes. Have a licensed attorney review before execution."`;

const MARKET_ASSISTANT_SYSTEM = `You are LeaseLens AI, an expert commercial real estate market analyst and lease negotiation advisor.

You have deep knowledge of:
• Commercial lease structures: NNN, gross, modified gross, full service
• CAM reconciliation, base year stops, expense caps
• Rent escalation structures: fixed step-ups, CPI, indexed
• Tenant improvement negotiation strategies
• Market conditions by asset class (office, retail, industrial, medical)
• Sublease and assignment market dynamics
• Co-tenancy clauses and radius restrictions (retail)
• SNDA, estoppel, and lender requirements
• Lease guarantee structures and burn-off provisions
• Early termination and lease restructuring
• 1031 exchange implications for commercial transactions
• NNN lease investment analysis (cap rate, NOI)
• Lease vs. own analysis
• Build-to-suit structures
• Sale-leaseback structures

Be direct, professional, and actionable. This is an enterprise audience — CRE brokers, asset managers, corporate real estate, and investors. Assume sophistication. Use industry terminology correctly. Keep under 400 words unless a detailed analysis is requested.`;

// ─────────────────────────────────────────────
// LICENSE KEYS
// ─────────────────────────────────────────────

const KEY_DB = new Map([
  ['LL-DEMO-00000000', { tier: 'professional', leasesPerMonth: 10, name: 'Demo User', active: true }],
]);

// ─────────────────────────────────────────────
// ROUTES
// ─────────────────────────────────────────────

app.get('/health', (_, res) => res.json({ ok: true, product: 'LeaseLens AI', v: '1.0.0' }));

app.post('/api/validate-key', (req, res) => {
  const key = req.body?.key?.toUpperCase().trim();
  const d = KEY_DB.get(key);
  if (!d?.active) return res.json({ valid: false });
  res.json({ valid: true, tier: d.tier, leasesPerMonth: d.leasesPerMonth, name: d.name });
});

// ── LEASE ABSTRACTION ──
app.post('/api/abstract', async (req, res) => {
  const { key, leaseText, propertyContext } = req.body;
  if (!KEY_DB.get(key?.toUpperCase())?.active) return res.status(401).json({ error: 'Invalid key' });
  if (!leaseText?.trim()) return res.status(400).json({ error: 'Lease text required' });

  const prompt = `COMMERCIAL LEASE DOCUMENT TO ABSTRACT:
${propertyContext ? `Property context: ${propertyContext}\n\n` : ''}
---
${leaseText.trim().slice(0, 80000)}
---
Extract all available information and return structured JSON as specified.`;

  try {
    const raw = await callClaude(ABSTRACTION_SYSTEM, prompt, 4000);
    const result = parseJSON(raw);
    if (!result) throw new Error('Could not parse abstraction response. The document may be too complex — try pasting a smaller section.');
    result.abstractedAt = new Date().toISOString();
    res.json({ result, timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── CLAUSE COMPARE ──
app.post('/api/compare', async (req, res) => {
  const { key, clauseType, leaseA, leaseB, labelA, labelB } = req.body;
  if (!KEY_DB.get(key?.toUpperCase())?.active) return res.status(401).json({ error: 'Invalid key' });

  const prompt = `Compare these two ${clauseType || 'lease'} clauses:

LEASE A (${labelA || 'Option A'}):
${leaseA}

LEASE B (${labelB || 'Option B'}):
${leaseB}

Clause type being compared: ${clauseType || 'unspecified'}`;

  try {
    const raw = await callClaude(CLAUSE_COMPARE_SYSTEM, prompt, 1200);
    const result = parseJSON(raw);
    if (!result) throw new Error('Parse error');
    res.json({ result, timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── LOI DRAFT ──
app.post('/api/loi', async (req, res) => {
  const { key, dealTerms } = req.body;
  if (!KEY_DB.get(key?.toUpperCase())?.active) return res.status(401).json({ error: 'Invalid key' });

  const prompt = `Draft a professional Letter of Intent for a commercial lease based on these deal terms:

Landlord: ${dealTerms.landlord || '[LANDLORD NAME]'}
Tenant: ${dealTerms.tenant || '[TENANT NAME]'}
Property: ${dealTerms.property || '[PROPERTY ADDRESS]'}
Suite/Space: ${dealTerms.suite || '[SUITE]'} — ${dealTerms.rsf || '[RSF]'} RSF
Lease term: ${dealTerms.term || '[TERM]'} months
Commencement: ${dealTerms.commencement || '[DATE]'}
Base rent: ${dealTerms.baseRent || '[$/SF/YEAR]'} per RSF per year
Rent escalations: ${dealTerms.escalations || '3% annually'}
OpEx structure: ${dealTerms.opex || 'NNN'}
Security deposit: ${dealTerms.deposit || '[AMOUNT]'}
TI allowance: ${dealTerms.ti || '[$/SF]'} per RSF
Free rent: ${dealTerms.freeRent || 'None'}
Renewal options: ${dealTerms.renewal || 'None'}
Permitted use: ${dealTerms.use || '[PERMITTED USE]'}
Parking: ${dealTerms.parking || 'Per building standard'}
Contingencies: ${dealTerms.contingencies || 'None'}
Special terms: ${dealTerms.notes || 'None'}
LOI expiration: ${dealTerms.loiExpiry || '5 business days from delivery'}

Draft the complete LOI now.`;

  try {
    const content = await callClaude(LOI_SYSTEM, prompt, 3000);
    res.json({ content, timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── MARKET ASSISTANT ──
app.post('/api/assistant', async (req, res) => {
  const { key, question, context } = req.body;
  if (!KEY_DB.get(key?.toUpperCase())?.active) return res.status(401).json({ error: 'Invalid key' });

  const ctx = context ? `\n\nContext: ${context}` : '';
  try {
    const answer = await callClaude(MARKET_ASSISTANT_SYSTEM, question + ctx, 1500);
    res.json({ answer, timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── ADMIN ──
app.post('/api/admin/generate-key', (req, res) => {
  if (req.headers['x-admin-secret'] !== process.env.ADMIN_SECRET) return res.status(401).json({ error: 'Unauthorized' });
  const { tier = 'professional', leasesPerMonth = 10, name = 'New Customer' } = req.body;
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let k = ''; for (let i = 0; i < 8; i++) k += chars[Math.floor(Math.random() * chars.length)];
  const key = `LL-${tier.toUpperCase().slice(0,4)}-${k}`;
  KEY_DB.set(key, { tier, leasesPerMonth, name, active: true, createdAt: new Date().toISOString() });
  res.json({ key, tier, leasesPerMonth, name });
});

const PORT = process.env.PORT || 3004;
app.listen(PORT, () => console.log(`LeaseLens AI API v1.0.0 — port ${PORT}`));
