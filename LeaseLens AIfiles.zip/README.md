# LeaseLens AI — Deployment Guide

> See every clause. Know every risk. Own every negotiation.
> Commercial lease intelligence for CRE professionals.

---

## Product overview

LeaseLens is the enterprise tier of the NormandinTECH real estate suite. It targets CRE brokers, asset managers, and corporate real estate teams with 4 AI modules:

1. **Lease Abstraction** — 100+ fields extracted, risk flags by severity, negotiation intelligence
2. **Clause Comparison** — Side-by-side analysis of any two lease provisions with market standard benchmarks
3. **LOI Drafter** — Professional Letter of Intent from deal terms in seconds
4. **Market Assistant** — Expert CRE lease Q&A on any topic

---

## Deploy in 4 steps

### Step 1 — Railway backend
1. Push `backend/` to GitHub repo `leaselens-api`
2. Connect to Railway, add:
   - `ANTHROPIC_API_KEY`
   - `ADMIN_SECRET`
   - `NODE_ENV=production`
3. Copy Railway URL

### Step 2 — Update API URL
In `app/index.html`:
```js
const API = 'https://leaselens-api.up.railway.app';
```

### Step 3 — Deploy frontend
```
/leaselens/
  landing/index.html   → /leaselens/index.html
  app/index.html       → /leaselens/app/index.html
  pwa/manifest.json    → /leaselens/manifest.json
  pwa/sw.js            → /leaselens/sw.js
  icons/               → /leaselens/icons/
```

### Step 4 — Gumroad products

| Product | Price | Notes |
|---------|-------|-------|
| Per-lease | $25 | Credit bundle, key LL-PLEA- |
| Professional | $199/month | Unlimited, LL-PROF- |
| Team | $499/month | 5 users, LL-TEAM- |

**Demo key:** `LL-DEMO-00000000`

**Generate keys:**
```bash
curl -X POST https://your-url/api/admin/generate-key \
  -H "x-admin-secret: YOUR_SECRET" \
  -H "Content-Type: application/json" \
  -d '{"tier":"professional","leasesPerMonth":999,"name":"Jane Smith"}'
```

---

## The full NormandinTECH real estate suite

| Product | Target | Price | Key prefix |
|---------|--------|-------|-----------|
| PropScribe AI | Real estate agents | $29–49/mo | PS- |
| RentGuard AI | Small landlords (1–10 units) | $19–79/mo | RG- |
| CloseTrack AI | Agents + TC firms | $12–99/mo | CT- |
| LeaseLens AI | CRE brokers, asset managers | $25–499/mo | LL- |

---

## API cost estimate

Lease abstraction uses 2,000–4,000 output tokens (large JSON).
At Sonnet pricing (~$0.015/1K output tokens):
- 50 abstractions = ~$3–6
- Revenue at $199/user: near 100% margin on abstraction module

Typical usage at Professional tier: 20–40 abstractions/month + LOI + assistant queries.
Total API cost per Professional user: ~$5–10/month at current pricing.
Net margin: ~95%+

---

## Key differentiators vs. competitors

| Feature | LeaseLens | Prophia | Lextract | Manual |
|---------|-----------|---------|----------|--------|
| Price | $25/lease or $199/mo | Enterprise ($$$) | $20/lease | $200–500/lease |
| Setup | Instant | Weeks | Instant | N/A |
| LOI drafting | ✓ | ✗ | ✗ | Separate tool |
| Clause comparison | ✓ | ✗ | ✗ | Manual |
| AI assistant | ✓ | ✗ | ✗ | Attorney |
| Contract free | ✓ | ✗ | ✓ | N/A |

---

## Launch checklist

- [ ] Backend deployed to Railway
- [ ] API URL updated in app/index.html
- [ ] Frontend deployed
- [ ] PWA icons in /leaselens/icons/ (realfavicongenerator.net)
- [ ] Demo key LL-DEMO-00000000 tested end-to-end
- [ ] All 4 modules tested
- [ ] Gumroad per-lease ($25) created
- [ ] Gumroad Professional ($199/mo) created
- [ ] Launch posts for: LinkedIn CRE groups, r/CommercialRealEstate, BiggerPockets CRE
- [ ] Email 10 CRE brokers with free Professional trial offer
